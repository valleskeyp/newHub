//
//  FirstViewController.m
//  project2
//
//  Created by Peter Valleskey on 6/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController.h"
#import "FirstViewControllerSecondPage.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

-(IBAction)onClick:(id)sender
{        
    FirstViewControllerSecondPage *FVCSecondPage = [[FirstViewControllerSecondPage alloc] initWithNibName:@"FirstViewControllerSecondPage" bundle:nil];
    if (FVCSecondPage != nil)
    {
        [self.navigationController pushViewController:FVCSecondPage animated:true];
    }
}
-(IBAction)login:(id)sender
{
    if (usernameInput.text.length == 0) 
    {
        if (pleaseEnter != nil) 
        {
            [pleaseEnter show];
        }
    } else {
        NSMutableString *combo = [[NSMutableString alloc] initWithString:@"User: "];
        [combo appendString:usernameInput.text];
        [combo appendString:@", has logged in."];
        usernameStatus.text = combo;
        usernameStatus.textColor = [UIColor greenColor];
        [self.view endEditing:true];
    }
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"First", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    pleaseEnter = [[UIAlertView alloc] initWithTitle:@"Error." message:@"Please enter a name in the field." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
