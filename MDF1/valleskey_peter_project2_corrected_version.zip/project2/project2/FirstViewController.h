//
//  FirstViewController.h
//  project2
//
//  Created by Peter Valleskey on 6/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
{
    IBOutlet UITextField *usernameInput;
    IBOutlet UILabel *usernameStatus;
    UIAlertView *pleaseEnter;
}
-(IBAction)onClick:(id)sender;
-(IBAction)login:(id)sender;
@end
